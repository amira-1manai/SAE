package tn.esprit.Spring.Entities;

public enum Specialite {
    IA, RESEAUX, CLOUD, SECURITE
}
