package tn.esprit.Spring.Entities;

public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT
}
