package tn.esprit.Spring.Entities;

public enum Option {
    GAMIX,
    SE,
    SIM,
    NIDS
}
