package tn.esprit.Exam.Services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.extern.slf4j.Slf4j;
import tn.esprit.Exam.Entity.Activite;
import tn.esprit.Exam.Entity.Evenement;
import tn.esprit.Exam.Entity.Role;
import tn.esprit.Exam.Entity.Utilisateur;
import tn.esprit.Exam.Repository.ActiviteRep;
import tn.esprit.Exam.Repository.EvenementRep;
import tn.esprit.Exam.Repository.UtilisateurRep;


@org.springframework.stereotype.Service
@Slf4j
public class Service implements IService {
	@Autowired
	UtilisateurRep ur;
	@Autowired
	EvenementRep er;
	@Autowired
	ActiviteRep ar;
	
	
	
	/*@Override
	 public Evenement addEvenement(Evenement e) {
		
		return er.save(e);
	}*/
	
	
	
	
	
	
	

}