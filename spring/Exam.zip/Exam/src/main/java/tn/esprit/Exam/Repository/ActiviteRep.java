package tn.esprit.Exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import tn.esprit.Exam.Entity.Activite;
import tn.esprit.Exam.Entity.Evenement;
@Repository
public interface ActiviteRep extends CrudRepository<Activite, Long>{
	

}
