package tn.esprit.Exam.Controller;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import tn.esprit.Exam.Entity.Activite;
import tn.esprit.Exam.Entity.Evenement;
import tn.esprit.Exam.Entity.Utilisateur;
import tn.esprit.Exam.Services.IService;



@RestController
@Slf4j

public class Controller {
	@Autowired // bch njib beha classe sans instantiation
	IService Is;

	
	/*
	@PostMapping("/Evenement/Add")
	Evenement ajouterEvenement(@RequestBody Evenement Evenement) {

		return Is.addEvenement(Evenement);
	}
	*/
	
	
}
