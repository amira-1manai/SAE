package tn.esprit.Exam.Services;

import java.util.List;

import tn.esprit.Exam.Entity.Activite;
import tn.esprit.Exam.Entity.Evenement;
import tn.esprit.Exam.Entity.Utilisateur;

public interface IService {

	
	//public Evenement addEvenement(Evenement e);

}
