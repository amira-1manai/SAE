package tn.esprit.Exam.Entity;

public enum Role {
	RESPONSABLE,PARTICIPANT
}
