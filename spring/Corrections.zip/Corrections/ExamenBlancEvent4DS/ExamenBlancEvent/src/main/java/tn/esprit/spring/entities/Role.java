package tn.esprit.spring.entities;

public enum Role {
	PARTICIPANT,RESPONSABLE
}
