package tn.esprit.spring.services;

import tn.esprit.spring.entities.Usine;

public interface IUsineService {
	
	Usine ajouterUsine (Usine u);
}
