package tn.esprit.spring.entities;

public enum TypeContrat {
	CIVP,CDI,CDD
}
