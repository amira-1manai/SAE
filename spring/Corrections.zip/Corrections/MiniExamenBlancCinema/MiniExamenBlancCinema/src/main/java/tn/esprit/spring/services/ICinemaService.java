package tn.esprit.spring.services;

import tn.esprit.spring.entities.Cinema;

public interface ICinemaService {
		
	Cinema ajouterCinema (Cinema c);
}
