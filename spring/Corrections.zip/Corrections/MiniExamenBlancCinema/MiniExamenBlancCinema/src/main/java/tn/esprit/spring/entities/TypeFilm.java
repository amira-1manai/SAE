package tn.esprit.spring.entities;

public enum TypeFilm {
	COMEDIE,HORREUR,SCIENTIFIQUE,ROMANTIQUE
}
